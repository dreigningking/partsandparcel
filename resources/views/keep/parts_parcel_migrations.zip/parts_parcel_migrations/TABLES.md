# Complete MVP table list

1. users — existing Laravel table; seller profile fields live here.
2. locations — buyer saved addresses and seller stock/service locations.
3. categories
4. brands
5. models
6. items — physical/owned item, including Seth's quantity-bearing batteries as items.
7. components — parts extracted from an item.
8. listings — buyer-facing sellable listing; polymorphic to item/component.
9. carts
10. cart_items
11. wishlists — no wishlist_items.
12. discussions — product requests, repair requests, installation requests, transport/delivery requests, etc.
13. responses — every community response consumes the subscriber's response allowance; an optional offer_id turns a response into an offer response.
14. offers — product or service offers; may come from a discussion and may have listing items.
15. offer_items — product listings included in an offer; service offers can use description without a listing.
16. orders
17. order_items
18. shipments — MVP can be manually managed; API integration can be added later.
19. subscription_plans
20. subscriptions — response_limit is snapshotted here; no subscription_usage table.
21. invoices — repairs, installations, transport/delivery services and other negotiated services.
22. invoice_items
23. payments — only money actually processed by Parts & Parcel.
24. revenues — platform commission/subscription/service revenue.
25. settlements — amounts owed to sellers/providers.
26. payouts — successful payout batches.
27. payout_settlements — settlements included in a payout batch.
28. refunds
29. refund_items
30. issues
31. issue_items
32. returns
33. return_items
34. replacements
35. replacement_items
36. disputes
37. dispute_items

No separate assets, inventory_items, component_types, model_components, seller_profiles, order_groups, wishlist_items, subscription_usage, or warranties table in the MVP.
