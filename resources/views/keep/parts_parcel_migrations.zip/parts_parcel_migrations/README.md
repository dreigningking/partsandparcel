# Parts & Parcel — MVP migration set

This migration set assumes Laravel's default `users` table already exists. It intentionally does not create `seller_profiles`, `assets`, `inventory_items`, `component_types`, `model_components`, `wishlist_items`, `order_groups`, or `subscription_usage`.

Warranty is kept simple for MVP:
- Product/listing warranty: `listings.warranty_period_days` + `warranty_terms`.
- The sold warranty is snapshotted on `order_items`.
- Repair/service warranty: `invoices.warranty_period_days`, `warranty_terms`, `warranty_starts_at`, `warranty_ends_at`.
- No separate `warranties` table is needed for MVP.

Forum delivery/repair/service requests use `discussions`; responses can carry an `offer`. Product offers point to listings through `offer_items`; service offers may have no listing and are associated with the discussion through `offers.discussion_id`. Accepted service offers can generate invoices.
